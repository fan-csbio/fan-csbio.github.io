#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统功能测试脚本 - 验证所有修改
"""

import os
import re

class SystemTester:
    def __init__(self):
        self.base_path = '/home/claude/loop_practice_system_v2'
        self.passed = 0
        self.failed = 0
        
    def test_file_structure(self):
        """测试1: 文件结构"""
        print("\n" + "="*60)
        print("测试1: 检查文件结构")
        print("="*60)
        
        required_files = ['index.html', 'app.js']
        for file in required_files:
            path = os.path.join(self.base_path, file)
            if os.path.exists(path):
                size = os.path.getsize(path)
                print(f"  ✓ {file} 存在 ({size:,} bytes)")
                self.passed += 1
            else:
                print(f"  ✗ {file} 不存在")
                self.failed += 1
                
    def test_removed_download_button(self):
        """测试2: 确认删除下载报告功能"""
        print("\n" + "="*60)
        print("测试2: 验证已删除'下载报告'功能")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 检查是否还有downloadReport相关代码
        if 'downloadReport' in content:
            print("  ✗ 仍存在downloadReport函数")
            self.failed += 1
        else:
            print("  ✓ 已删除downloadReport函数")
            self.passed += 1
            
        html_path = os.path.join(self.base_path, 'index.html')
        with open(html_path, 'r', encoding='utf-8') as f:
            html = f.read()
            
        if '下载报告' in html or 'downloadReport' in html:
            print("  ✗ HTML中仍存在下载报告相关内容")
            self.failed += 1
        else:
            print("  ✓ HTML中已删除下载报告相关内容")
            self.passed += 1
            
    def test_restart_function(self):
        """测试3: 验证再次测试功能"""
        print("\n" + "="*60)
        print("测试3: 验证'再次测试'功能")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'function restartTest()' in content:
            print("  ✓ restartTest函数存在")
            self.passed += 1
            
            # 检查是否清空answeredQuestions
            if 'answeredQuestions = []' in content:
                print("  ✓ 清空答题记录")
                self.passed += 1
            else:
                print("  ✗ 未清空答题记录")
                self.failed += 1
                
            # 检查是否切换到practice页面
            if "document.getElementById('practice').classList.add('active')" in content:
                print("  ✓ 切换到练习页面")
                self.passed += 1
            else:
                print("  ✗ 未切换到练习页面")
                self.failed += 1
                
            # 检查是否隐藏analysis页面
            if "document.getElementById('analysis').classList.remove('active')" in content:
                print("  ✓ 隐藏分析页面")
                self.passed += 1
            else:
                print("  ✗ 未隐藏分析页面")
                self.failed += 1
        else:
            print("  ✗ restartTest函数不存在")
            self.failed += 1
            
    def test_question_type_pages(self):
        """测试4: 验证题型子页面"""
        print("\n" + "="*60)
        print("测试4: 验证题型子页面")
        print("="*60)
        
        html_path = os.path.join(self.base_path, 'index.html')
        with open(html_path, 'r', encoding='utf-8') as f:
            html = f.read()
            
        # 检查子导航
        if 'sub-nav-tabs' in html:
            print("  ✓ 子导航栏存在")
            self.passed += 1
        else:
            print("  ✗ 子导航栏不存在")
            self.failed += 1
            
        # 检查三个题型容器
        containers = ['choiceQuestions', 'judgeQuestions', 'codingQuestions']
        for container in containers:
            if f'id="{container}"' in html:
                print(f"  ✓ {container}容器存在")
                self.passed += 1
            else:
                print(f"  ✗ {container}容器不存在")
                self.failed += 1
                
    def test_render_all_questions(self):
        """测试5: 验证显示所有题目功能"""
        print("\n" + "="*60)
        print("测试5: 验证显示所有题目功能")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'function renderQuestionsByType' in content:
            print("  ✓ renderQuestionsByType函数存在")
            self.passed += 1
            
            # 检查是否过滤题目
            if 'questionBank.filter(q => q.type === type)' in content:
                print("  ✓ 按类型过滤题目")
                self.passed += 1
            else:
                print("  ✗ 未按类型过滤题目")
                self.failed += 1
                
            # 检查是否渲染所有题目
            if 'questions.forEach' in content:
                print("  ✓ 遍历渲染所有题目")
                self.passed += 1
            else:
                print("  ✗ 未遍历渲染所有题目")
                self.failed += 1
        else:
            print("  ✗ renderQuestionsByType函数不存在")
            self.failed += 1
            
    def test_submit_button(self):
        """测试6: 验证每题都有提交按钮"""
        print("\n" + "="*60)
        print("测试6: 验证每题都有提交按钮")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 检查renderSingleQuestion函数
        if 'function renderSingleQuestion' in content:
            print("  ✓ renderSingleQuestion函数存在")
            self.passed += 1
            
            # 检查是否有提交按钮
            if 'submitAnswer' in content and 'btn-primary' in content:
                print("  ✓ 包含提交答案按钮")
                self.passed += 1
            else:
                print("  ✗ 未包含提交答案按钮")
                self.failed += 1
        else:
            print("  ✗ renderSingleQuestion函数不存在")
            self.failed += 1
            
    def test_removed_skip_button(self):
        """测试7: 验证已删除跳过按钮"""
        print("\n" + "="*60)
        print("测试7: 验证已删除'跳过此题'按钮")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'skipQuestion' in content:
            print("  ✗ 仍存在skipQuestion函数")
            self.failed += 1
        else:
            print("  ✓ 已删除skipQuestion函数")
            self.passed += 1
            
        if '跳过此题' in content or '跳过' in content:
            print("  ✗ 代码中仍包含'跳过'相关内容")
            self.failed += 1
        else:
            print("  ✓ 已删除'跳过'相关内容")
            self.passed += 1
            
    def test_question_bank_size(self):
        """测试8: 验证题库完整性"""
        print("\n" + "="*60)
        print("测试8: 验证题库完整性")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 统计题目
        choice_count = content.count("type: 'choice'")
        judge_count = content.count("type: 'judge'")
        coding_count = content.count("type: 'coding'")
        total = choice_count + judge_count + coding_count
        
        print(f"  选择题: {choice_count}题")
        print(f"  判断题: {judge_count}题")
        print(f"  编程题: {coding_count}题")
        print(f"  总计: {total}题")
        
        if total >= 20:
            print(f"  ✓ 题目数量充足 ({total}题)")
            self.passed += 1
        else:
            print(f"  ✗ 题目数量不足 ({total}题)")
            self.failed += 1
            
    def test_irt_functionality(self):
        """测试9: 验证IRT功能"""
        print("\n" + "="*60)
        print("测试9: 验证IRT功能")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        irt_functions = [
            'class IRTEngine',
            'calculateProbability',
            'updateTheta',
            'getAbilityLevel'
        ]
        
        for func in irt_functions:
            if func in content:
                print(f"  ✓ {func}存在")
                self.passed += 1
            else:
                print(f"  ✗ {func}不存在")
                self.failed += 1
                
    def test_code_judge_functionality(self):
        """测试10: 验证代码评判功能"""
        print("\n" + "="*60)
        print("测试10: 验证代码评判功能")
        print("="*60)
        
        js_path = os.path.join(self.base_path, 'app.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        judge_functions = [
            'class CodeJudgeEngine',
            'judgeCode',
            'testCorrectness',
            'analyzeQuality',
            'analyzePerformance',
            'checkBestPractices'
        ]
        
        for func in judge_functions:
            if func in content:
                print(f"  ✓ {func}存在")
                self.passed += 1
            else:
                print(f"  ✗ {func}不存在")
                self.failed += 1
                
    def run_all_tests(self):
        """运行所有测试"""
        print("\n" + "="*60)
        print("🧪 开始系统功能测试")
        print("="*60)
        
        self.test_file_structure()
        self.test_removed_download_button()
        self.test_restart_function()
        self.test_question_type_pages()
        self.test_render_all_questions()
        self.test_submit_button()
        self.test_removed_skip_button()
        self.test_question_bank_size()
        self.test_irt_functionality()
        self.test_code_judge_functionality()
        
        # 输出总结
        print("\n" + "="*60)
        print("📊 测试结果总结")
        print("="*60)
        total = self.passed + self.failed
        print(f"\n通过: {self.passed}/{total}")
        print(f"失败: {self.failed}/{total}")
        
        if self.failed == 0:
            print("\n🎉 所有测试通过！系统功能正常")
            return True
        else:
            print(f"\n⚠️ 有{self.failed}个测试失败")
            return False

if __name__ == '__main__':
    tester = SystemTester()
    success = tester.run_all_tests()
    exit(0 if success else 1)
